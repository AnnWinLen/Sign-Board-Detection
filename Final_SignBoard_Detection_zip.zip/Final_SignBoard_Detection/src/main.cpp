#include <Arduino.h>
#include <main.h>
#include <Wire.h>
#include <TinyGPS++.h>
#include <LiquidCrystal_I2C.h>

/*gps*/
// long   lat,lon; // create variable for latitude and longitude object
float lat, lon;
TinyGPSPlus gps; // create gps object
LiquidCrystal_I2C lcd(0x27, 20, 4);

void Stop();
void right();
void left();
void backward();
void forward();

void setup()
{
  Serial.begin(115200);

  Serial1.begin(9600); // for receiving value from pi
  Serial2.begin(9600); // for gps
  Serial3.begin(9600); // for Bluetooth

  Serial.println("Start..");

  pinMode(motorPin, OUTPUT);
  pinMode(m11, OUTPUT);
  pinMode(m12, OUTPUT);
  pinMode(m21, OUTPUT);
  pinMode(m22, OUTPUT);
  // pinMode(EN_A, OUTPUT);
  // pinMode(EN_B, OUTPUT);
  analogWrite(m11, 0);
  analogWrite(m12, 0);
  analogWrite(m21, 0);
  analogWrite(m22, 0);

  lcd.init(); // initialize the lcd
  lcd.backlight();
}

void loop()
{

  // analogWrite(motorPin, motor_in);
  lcd.setCursor(0, 1);
  lcd.print("SPEED:");
  lcd.print(current_speed);
  // lcd.print("Long: ");
  if (current_speed == 0)
  {
    lcd.setCursor(9, 1);
    lcd.print("IN:");
    lcd.print("000");
  }
  else
  {
    lcd.setCursor(9, 1);
    lcd.print("IN:");
    lcd.print(motor_in);
  }

  //**************************************************************
  /*reading values from pi*/

  if (Serial1.available() > 0)
  {
    char _char = Serial1.read(); // It will read the incoming or arriving data byte
                                 // Serial.write(_char);
    // Serial.print(_char);
    serial_data_buf[serial_data_buf_index] = _char;

    serial_data_buf_index++;
    // Serial1.write(serial_data_buf);
    if (serial_data_buf_index >= SERIAL_DATA_BUF)
    {
      serial_data_buf_index = 0;
    }

    if (_char == SERIAL_DATA_ENDCHAR)
    {
      serial_data_buf[serial_data_buf_index] = '\0';

      data_received = true;
      serial_data_buf_index = 0;

      // Serial.println(serial_data_buf);
    }
  }

  if (data_received)
  {
    data_received = false;
    Serial.print("Data from pi = ");
    Serial.print(serial_data_buf);
    speed_pi = atoi(serial_data_buf); // converting character array to integer

    Serial.print("speed_pi,current_speed = ");
    Serial.print(speed_pi);
    Serial.print(",");
    Serial.println(current_speed);

    if (speed_pi == 30)
    {
      if (current_speed > 30)
      {
        // motor_in = map(speed_pi, 0, 50, 0, 255);
        motor_in = 200;
        Serial.println("Speed_30");
        current_speed = speed_pi;
      }
    }

    else if (speed_pi == 10)
    {
      if (current_speed > 10)
      {
        // motor_in = map(speed_pi, 0, 50, 0, 255);
        motor_in = 150;
        Serial.println("Speed_10");
        current_speed = speed_pi;
      }
    }

    else if (speed_pi == 999)
      if (millis() - Update_Prev_MS >= STOP_UPDATE_MS)
      {
        {
          count++;
          Update_Prev_MS = millis();
        }
        if (count > 1)
        {
          motor_in = 0;
          Serial.println("stop");
          current_speed = 0;
          count = 0;
        }
            }

    Serial.print("Current_speed = ");
    Serial.println(current_speed);
    Serial.print("motor_in = ");
    Serial.println(motor_in);
    Serial.println("***********************************");
    Serial.println();
  }
  //*****************************************************************
  // /* taking values from gps*/
  while (Serial2.available())
  {                                 // check for gps data
    if (gps.encode(Serial2.read())) // encode gps data
    {

      // //Latitude
      // Serial.print("Latitude: ");
      // Serial.println(gps.location.lat(),6);

      // //Longitude
      // Serial.print("Longitude: ");
      // Serial.println(gps.location.lng(),6);
      //
      //    //Altitude
      //    Serial.print("Altitude: ");
      //    Serial.println(gps.altitude.feet());

      //    //Speed
      //    Serial.print("Speed: ");
      //    Serial.println(gps.speed.mph());
      //
      //    // Number of satellites connected
      //    Serial.print("Number of Sats connected: ");
      //    Serial.println(gps.satellites.value());

      // delay(2000);
      lcd.setCursor(0, 0); // I2C Lcd Display
                           // lcd.print("LA:");
      lcd.print(gps.location.lat(), 3);

      lcd.setCursor(7, 0);
      lcd.print(",");
      lcd.print(gps.location.lng(), 3);
    }
  }
  //*************************************************************
  /* receiving values from bluetooth*/
  while (Serial3.available())
  {
    delay(10);
    char c = Serial3.read();
    Serial.println(c);

    if (c == '8')
    {
      Serial.println("forward");
      forward();
    }

    else if (c == '2')
    {

      backward();
      Serial.println("back");
    }
    else if (c == '4')
    {

      Serial.println("right");
      right();
    }
    else if (c == '6')
    {

      Serial.println("left");
      left();
    }
    else if (c == '0')
    {

      Serial.println("stop");
      Stop();
    }
  }
}

/*bluetooth*/
void forward()
{

  analogWrite(m11, motor_in);
  analogWrite(m12, 0);
  analogWrite(m21, 0);
  analogWrite(m22, motor_in);
}
void backward()
{

  // Serial.println("backward");

  analogWrite(m11, 0);
  analogWrite(m12, motor_in);
  analogWrite(m21, motor_in);
  analogWrite(m22, 0);
}
void left()
{
  analogWrite(m11, motor_in);
  analogWrite(m12, 0);
  analogWrite(m21, 0);
  analogWrite(m22, 0);
}
void right()
{

  // Serial.println("right");

  analogWrite(m11, 0);
  analogWrite(m12, 0);
  analogWrite(m21, 0);
  analogWrite(m22, motor_in);
}
void Stop()
{
  // Serial.println("stop");

  analogWrite(m11, 0);
  analogWrite(m12, 0);
  analogWrite(m21, 0);
  analogWrite(m22, 0);
}