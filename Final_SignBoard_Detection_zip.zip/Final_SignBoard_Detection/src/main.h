#include <Arduino.h>

const byte motorPin = 9;
int current_speed = 50;
int motor_in = 255;
// int motor_in;

unsigned long Update_Prev_MS = 0;
const unsigned long STOP_UPDATE_MS = 100;
int count = 0;

bool serial_data_available = false;
bool data_received = false;

#define SERIAL_DATA_BUF 40
#define SERIAL_DATA_ENDCHAR '\n'

char serial_data_buf[SERIAL_DATA_BUF];
uint8_t serial_data_buf_index = 0;

// bluetooth
const int m11 = 3;
const int m12 = 5;
const int m21 = 10;
const int m22 = 11;
const int EN_A = 7;
const int EN_B = 8;
int speed;
 int speed_pi;